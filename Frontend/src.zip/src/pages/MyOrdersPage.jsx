import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  CalendarDays,
  ExternalLink,
  Filter,
  IndianRupee,
  MapPin,
  Package,
  Search,
  Truck,
} from "lucide-react";

const STATUS_STYLES = {
  Delivered: "bg-emerald-100 text-emerald-800 ring-emerald-200",
  Shipped: "bg-sky-100 text-sky-800 ring-sky-200",
  Cancelled: "bg-red-100 text-red-800 ring-red-200",
  default: "bg-gray-100 text-gray-700 ring-gray-200",
};

const orders = [
  {
    id: "ORD-99210",
    date: "Oct 24, 2025",
    total: 1249,
    status: "Delivered",
    items: ["Wireless Headphones", "Hard Case"],
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300",
    shippingAddress: "123 Tech Park, Whitefield, Bangalore, KA - 560066",
  },
  {
    id: "ORD-88124",
    date: "Nov 02, 2025",
    total: 85.5,
    status: "Shipped",
    items: ["USB-C Cable (2m)"],
    image: "https://images.unsplash.com/photo-1619190163488-db0e33e70a60?w=300",
    shippingAddress:
      "Flat 405, Green Heights, HSR Layout, Bangalore, KA - 560102",
  },
  {
    id: "ORD-77102",
    date: "Nov 10, 2025",
    total: 450,
    status: "Cancelled",
    items: ["Smart Watch Series 5"],
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300",
    shippingAddress: "Home, Near City Mall, Gulbarga, KA - 585103",
  },
];

const FILTERS = ["All", "Delivered", "Shipped", "Cancelled"];

const formatCurrency = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);

const MyOrdersPage = () => {
  const [activeFilter, setActiveFilter] = useState("All");

  const filteredOrders = useMemo(() => {
    if (activeFilter === "All") return orders;
    return orders.filter((order) => order.status === activeFilter);
  }, [activeFilter]);

  if (!orders.length) {
    return (
      <main className="bg-[#f6f7fb] px-4 py-8">
        <div className="mx-auto max-w-6xl">
          <EmptyState />
        </div>
      </main>
    );
  }

  return (
    <main className="bg-[#f6f7fb] px-4 py-6 sm:px-6 lg:px-8">
      <section className="mx-auto max-w-6xl space-y-6">
        <Header />

        <div className="overflow-x-auto rounded-2xl border border-gray-200 bg-white p-2 shadow-sm">
          <div className="flex min-w-max gap-2">
            {FILTERS.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`rounded-xl px-4 py-2.5 text-sm font-bold transition ${
                  activeFilter === filter
                    ? "bg-[#ea2e0e] text-white shadow-sm"
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-950"
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <OrderCard key={order.id} order={order} />
          ))}

          {filteredOrders.length === 0 && <EmptyState />}
        </div>
      </section>
    </main>
  );
};

const Header = () => (
  <div className="overflow-hidden rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-[#ea2e0e] p-5 text-white shadow-sm sm:p-6">
    <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="text-sm font-semibold uppercase tracking-wide text-white/60">
          Account
        </p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
          Purchase History
        </h1>
        <p className="mt-2 max-w-xl text-sm text-white/70">
          Review orders, delivery progress, and shipping details.
        </p>
      </div>

      <button
        type="button"
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-bold text-slate-950 shadow-sm transition hover:bg-orange-50 sm:w-auto"
      >
        <Filter size={17} />
        Filter Orders
      </button>
    </div>
  </div>
);

const OrderCard = ({ order }) => {
  const isShipped = order.status === "Shipped";

  return (
    <article className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition hover:shadow-md">
      <div className="border-l-4 border-[#ea2e0e] p-4 sm:p-5">
        <div className="grid gap-5 lg:grid-cols-[1fr_190px] lg:items-center">
          <div className="grid gap-4 sm:grid-cols-[112px_1fr]">
            <div className="relative h-28 w-full overflow-hidden rounded-xl bg-gray-100 sm:w-28">
              <img
                src={order.image}
                alt={order.items[0]}
                className="h-full w-full object-cover"
              />

              {order.items.length > 1 && (
                <span className="absolute right-2 top-2 rounded-full bg-[#ea2e0e] px-2 py-1 text-xs font-bold text-white shadow-sm">
                  +{order.items.length - 1}
                </span>
              )}
            </div>

            <div className="min-w-0">
              <div className="flex flex-col gap-3 border-b border-gray-100 pb-4 md:flex-row md:items-start md:justify-between">
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-wide text-gray-400">
                    Order ID
                  </p>
                  <Link
                    to={`/orders/${order.id}`}
                    className="mt-1 inline-flex items-center gap-1 break-all text-base font-bold text-gray-950 transition hover:text-[#ea2e0e]"
                  >
                    {order.id}
                    <ExternalLink size={15} />
                  </Link>
                </div>

                <div className="flex flex-wrap gap-2">
                  <MetaChip icon={CalendarDays} text={order.date} />
                  <MetaChip
                    icon={IndianRupee}
                    text={formatCurrency(order.total)}
                  />
                  <StatusBadge status={order.status} />
                </div>
              </div>

              <div className="grid gap-4 pt-4 md:grid-cols-2">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-gray-400">
                    Items
                  </p>
                  <p className="mt-1 text-sm font-semibold leading-6 text-gray-700">
                    {order.items.join(", ")}
                  </p>
                </div>

                <div className="flex items-start gap-2">
                  <MapPin
                    size={16}
                    className="mt-0.5 shrink-0 text-[#ea2e0e]"
                  />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-gray-400">
                      Shipping To
                    </p>
                    <p className="mt-1 text-sm leading-6 text-gray-600">
                      {order.shippingAddress}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
            <Link
              to={`/orders/${order.id}`}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-bold text-white transition hover:bg-[#ea2e0e]"
            >
              <Search size={16} />
              View Details
            </Link>

            <button
              type="button"
              className={`inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition ${
                isShipped
                  ? "bg-[#ea2e0e] text-white hover:bg-[#d92a0c]"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Truck size={16} />
              {isShipped ? "Track Order" : "View Status"}
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};

const MetaChip = ({ icon: Icon, text }) => (
  <span className="inline-flex items-center gap-1.5 rounded-full bg-gray-100 px-3 py-1 text-xs font-bold text-gray-700">
    <Icon size={14} />
    {text}
  </span>
);

const StatusBadge = ({ status }) => (
  <span
    className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ring-1 ${
      STATUS_STYLES[status] || STATUS_STYLES.default
    }`}
  >
    {status}
  </span>
);

const EmptyState = () => (
  <div className="rounded-2xl border border-dashed border-gray-200 bg-white px-6 py-16 text-center">
    <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-gray-100">
      <Package size={34} className="text-gray-400" />
    </div>

    <h3 className="text-lg font-bold text-gray-950">No orders found</h3>
    <p className="mt-2 text-sm text-gray-500">
      Your recent purchases will appear here.
    </p>

    <button
      type="button"
      className="mt-6 rounded-xl bg-[#ea2e0e] px-6 py-3 text-sm font-bold text-white transition hover:bg-[#d92a0c]"
    >
      Start Shopping
    </button>
  </div>
);

export default MyOrdersPage;
