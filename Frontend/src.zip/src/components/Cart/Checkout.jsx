import React, { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  FiArrowLeft,
  FiCheckCircle,
  FiCreditCard,
  FiLoader,
  FiLock,
  FiMapPin,
  FiPackage,
} from "react-icons/fi";
import { useShop } from "./ShopContext";

const FREE_SHIPPING_LIMIT = 5000;
const SHIPPING_FEE = 150;

const initialShipping = {
  fullName: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  zip: "",
};

const formatCurrency = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);

const Checkout = () => {
  const { state } = useLocation();
  const navigate = useNavigate();

  // Read live cart items and clearCart method from ShopContext
  const { cartProducts: contextCartItems, clearCart } = useShop();

  // Prefer router state if passed, otherwise fall back to live context items
  const cartItems = state?.cartProducts || contextCartItems;

  const [shipping, setShipping] = useState(initialShipping);
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [errors, setErrors] = useState({});
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  const pricing = useMemo(() => {
    const subtotal = cartItems.reduce(
      (total, item) => total + item.price * item.quantity,
      0,
    );

    const delivery = subtotal >= FREE_SHIPPING_LIMIT ? 0 : SHIPPING_FEE;

    return {
      subtotal,
      delivery,
      total: subtotal + delivery,
    };
  }, [cartItems]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setShipping((current) => ({
      ...current,
      [name]: value,
    }));

    setErrors((current) => ({
      ...current,
      [name]: "",
    }));
  };

  const validateForm = () => {
    const nextErrors = {};

    if (!shipping.fullName.trim())
      nextErrors.fullName = "Full name is required";
    if (!shipping.email.trim()) nextErrors.email = "Email is required";
    if (!shipping.address.trim()) nextErrors.address = "Address is required";
    if (!shipping.city.trim()) nextErrors.city = "City is required";
    if (!shipping.zip.trim()) nextErrors.zip = "Postal code is required";

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const placeOrder = () => {
    if (!validateForm()) return;

    setIsPlacingOrder(true);

    const order = {
      orderId: `ORD-${Date.now()}`,
      items: cartItems,
      customer: shipping,
      paymentMethod,
      pricing,
      total: pricing.total,
      createdAt: new Date().toISOString(),
      status: paymentMethod === "cod" ? "confirmed" : "payment_pending",
    };

    try {
      localStorage.setItem("latestOrder", JSON.stringify(order));
    } catch {
      // Checkout can continue even when localStorage is blocked.
    }

    setTimeout(() => {
      clearCart(); // Clear active cart upon order placement
      setIsPlacingOrder(false);
      navigate("/order-confirmation", { state: order });
    }, 1200);
  };

  if (!cartItems.length) {
    return <EmptyCheckout onShop={() => navigate("/")} />;
  }

  return (
    <main className="min-h-screen bg-[#f6f7fb] p-4 text-gray-950 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm font-bold text-gray-700 shadow-sm transition hover:border-[#ea2e0e]/30 hover:bg-orange-50 hover:text-[#ea2e0e]"
        >
          <FiArrowLeft size={16} />
          Return to Bag
        </button>

        <header className="overflow-hidden rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-[#ea2e0e] p-5 text-white shadow-sm sm:p-6">
          <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-white/60">
                Secure Checkout
              </p>
              <h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
                Complete Your Order
              </h1>
              <p className="mt-2 max-w-xl text-sm text-white/70">
                Add your shipping details, choose a payment method, and review
                everything before placing the order.
              </p>
            </div>

            <div className="rounded-xl bg-white/10 px-4 py-3 ring-1 ring-white/15">
              <p className="text-xs font-semibold uppercase tracking-wide text-white/55">
                Checkout Total
              </p>
              <p className="mt-1 text-2xl font-bold text-white">
                {formatCurrency(pricing.total)}
              </p>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <section className="space-y-6 lg:col-span-7">
            <Panel icon={<FiMapPin />} title="Shipping Address">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Field
                  label="Full Name"
                  name="fullName"
                  value={shipping.fullName}
                  error={errors.fullName}
                  onChange={handleChange}
                  placeholder="Akash Bojja"
                  autoComplete="name"
                />

                <Field
                  label="Email"
                  name="email"
                  type="email"
                  value={shipping.email}
                  error={errors.email}
                  onChange={handleChange}
                  placeholder="akash@example.com"
                  autoComplete="email"
                />

                <Field
                  label="Phone"
                  name="phone"
                  value={shipping.phone}
                  onChange={handleChange}
                  placeholder="+91 98765 43210"
                  autoComplete="tel"
                />

                <Field
                  label="Postal Code"
                  name="zip"
                  value={shipping.zip}
                  error={errors.zip}
                  onChange={handleChange}
                  placeholder="585101"
                  autoComplete="postal-code"
                />

                <div className="md:col-span-2">
                  <Field
                    label="Street Address"
                    name="address"
                    value={shipping.address}
                    error={errors.address}
                    onChange={handleChange}
                    placeholder="House no, street, area"
                    autoComplete="street-address"
                  />
                </div>

                <Field
                  label="City"
                  name="city"
                  value={shipping.city}
                  error={errors.city}
                  onChange={handleChange}
                  placeholder="Kalaburagi"
                  autoComplete="address-level2"
                />
              </div>
            </Panel>

            <Panel icon={<FiCreditCard />} title="Payment Method">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <PaymentButton
                  active={paymentMethod === "cod"}
                  title="Cash on Delivery"
                  subtitle="Pay when your order arrives"
                  onClick={() => setPaymentMethod("cod")}
                />

                <PaymentButton
                  active={paymentMethod === "paypal"}
                  title="PayPal"
                  subtitle="Continue with secure wallet"
                  onClick={() => setPaymentMethod("paypal")}
                />
              </div>
            </Panel>
          </section>

          <aside className="lg:col-span-5">
            <OrderSummary
              items={cartItems}
              pricing={pricing}
              paymentMethod={paymentMethod}
              isPlacingOrder={isPlacingOrder}
              onPlaceOrder={placeOrder}
            />
          </aside>
        </div>
      </div>
    </main>
  );
};

const Panel = ({ icon, title, children }) => (
  <section className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
    <div className="flex items-center gap-3 border-b border-gray-200 px-4 py-4 sm:px-6">
      <div className="grid h-11 w-11 place-items-center rounded-xl bg-[#ea2e0e]/10 text-[#ea2e0e]">
        {icon}
      </div>
      <h2 className="text-lg font-bold text-gray-950">{title}</h2>
    </div>

    <div className="p-4 sm:p-6">{children}</div>
  </section>
);

const Field = ({ label, error, ...props }) => (
  <label className="block">
    <span className="mb-2 block text-sm font-bold text-gray-800">{label}</span>

    <input
      {...props}
      className={`h-12 w-full rounded-xl border bg-white px-4 text-sm font-semibold text-gray-950 outline-none transition placeholder:text-gray-400 focus:ring-2 ${
        error
          ? "border-red-300 focus:border-red-500 focus:ring-red-500/15"
          : "border-gray-200 focus:border-[#ea2e0e] focus:ring-[#ea2e0e]/15"
      }`}
    />

    {error && (
      <span className="mt-2 block text-sm font-medium text-red-600">
        {error}
      </span>
    )}
  </label>
);

const PaymentButton = ({ active, title, subtitle, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    aria-pressed={active}
    className={`flex items-center gap-4 rounded-xl border p-4 text-left transition ${
      active
        ? "border-[#ea2e0e] bg-[#ea2e0e]/5 shadow-sm"
        : "border-gray-200 bg-white hover:border-[#ea2e0e]/30 hover:bg-orange-50"
    }`}
  >
    <span
      className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border ${
        active
          ? "border-[#ea2e0e] bg-[#ea2e0e] text-white"
          : "border-gray-300 text-transparent"
      }`}
    >
      <FiCheckCircle size={14} />
    </span>

    <span>
      <span className="block text-sm font-bold text-gray-950">{title}</span>
      <span className="mt-1 block text-xs font-semibold text-gray-500">
        {subtitle}
      </span>
    </span>
  </button>
);

const OrderSummary = ({
  items,
  pricing,
  paymentMethod,
  isPlacingOrder,
  onPlaceOrder,
}) => (
  <div className="sticky top-6 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
    <div className="flex items-center justify-between border-b border-gray-200 px-4 py-4 sm:px-6">
      <div>
        <h3 className="text-lg font-bold text-gray-950">Order Summary</h3>
        <p className="mt-1 text-sm text-gray-500">
          {items.length} item{items.length === 1 ? "" : "s"} selected
        </p>
      </div>
      <div className="grid h-11 w-11 place-items-center rounded-xl bg-[#ea2e0e]/10 text-[#ea2e0e]">
        <FiPackage size={20} />
      </div>
    </div>

    <div className="max-h-72 space-y-4 overflow-y-auto bg-gray-50/60 p-4 sm:p-6">
      {items.map((item) => (
        <div
          key={item.productID}
          className="rounded-xl border border-gray-200 bg-white p-3 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="h-20 w-16 shrink-0 overflow-hidden rounded-xl bg-gray-100">
              <img
                src={item.image}
                alt={item.name}
                className="h-full w-full object-cover"
              />
            </div>

            <div className="min-w-0 flex-1">
              <p className="line-clamp-2 text-sm font-bold text-gray-950">
                {item.name}
              </p>
              <p className="mt-1 text-xs font-semibold text-gray-500">
                Qty {item.quantity}
              </p>
            </div>

            <p className="shrink-0 text-sm font-bold text-gray-950">
              {formatCurrency(item.price * item.quantity)}
            </p>
          </div>
        </div>
      ))}
    </div>

    <div className="p-4 sm:p-6">
      <div className="space-y-4">
        <SummaryRow label="Subtotal" value={formatCurrency(pricing.subtotal)} />
        <SummaryRow
          label="Shipping"
          value={
            pricing.delivery === 0
              ? "Complimentary"
              : formatCurrency(pricing.delivery)
          }
          highlight={pricing.delivery === 0}
        />

        <div className="flex items-end justify-between border-t border-gray-100 pt-5">
          <span className="text-sm font-bold text-gray-500">Total</span>
          <span className="text-3xl font-bold tracking-tight text-[#ea2e0e]">
            {formatCurrency(pricing.total)}
          </span>
        </div>
      </div>

      <button
        type="button"
        disabled={isPlacingOrder}
        onClick={onPlaceOrder}
        className="mt-6 flex w-full items-center justify-center gap-3 rounded-xl bg-slate-950 px-6 py-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#ea2e0e] active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-400"
      >
        {isPlacingOrder ? (
          <>
            <FiLoader className="animate-spin" size={16} />
            Processing
          </>
        ) : (
          <>
            <FiLock size={15} />
            {paymentMethod === "paypal" ? "Continue to PayPal" : "Place Order"}
          </>
        )}
      </button>

      <p className="mt-5 text-center text-xs font-semibold text-gray-400">
        Encrypted checkout / 30 day returns
      </p>
    </div>
  </div>
);

const SummaryRow = ({ label, value, highlight = false }) => (
  <div className="flex items-center justify-between text-sm">
    <span className="font-semibold text-gray-500">{label}</span>
    <span
      className={`font-bold ${highlight ? "text-emerald-600" : "text-gray-950"}`}
    >
      {value}
    </span>
  </div>
);

const EmptyCheckout = ({ onShop }) => (
  <main className="grid min-h-screen place-items-center bg-[#f6f7fb] px-6 text-center">
    <div className="rounded-2xl border border-gray-200 bg-white px-6 py-10 shadow-sm">
      <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-[#ea2e0e]/10 text-[#ea2e0e]">
        <FiPackage size={30} />
      </div>

      <h1 className="text-xl font-bold text-gray-950">Your cart is empty</h1>
      <p className="mt-2 text-sm text-gray-500">
        Add products to your bag before checkout.
      </p>

      <button
        type="button"
        onClick={onShop}
        className="mt-6 rounded-xl bg-slate-950 px-6 py-3 text-sm font-bold text-white transition hover:bg-[#ea2e0e]"
      >
        Start Shopping
      </button>
    </div>
  </main>
);

export default Checkout;
