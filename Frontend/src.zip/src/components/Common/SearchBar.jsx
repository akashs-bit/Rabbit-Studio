import React, { useEffect, useRef, useState } from "react";
import { HiMagnifyingGlass, HiMiniXMark } from "react-icons/hi2";

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const inputRef = useRef(null);

  const toggleSearch = () => setIsOpen((prev) => !prev);

  const handleSearch = (e) => {
    e.preventDefault();
    console.log("Search:", searchTerm);
    setIsOpen(false);
  };

  // Auto focus + ESC close
  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

    const handleEsc = (e) => {
      if (e.key === "Escape") setIsOpen(false);
    };

    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [isOpen]);

  return (
    <>
      {/* Search Icon */}
      {!isOpen && (
        <button onClick={toggleSearch}>
          <HiMagnifyingGlass className="h-6 w-6 text-gray-700 hover:text-black" />
        </button>
      )}

      {/* Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-start justify-center">
          {/* Search Box */}
          <div className="w-full bg-white py-6 px-4 sm:px-6 md:px-10 shadow-md">
            {/* Top Row */}
            <div className="max-w-3xl mx-auto flex items-center gap-4">
              {/* Input */}
              <form onSubmit={handleSearch} className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-gray-100 px-4 py-3 pr-12 rounded-md focus:outline-none focus:ring-2 focus:ring-black text-sm"
                />

                {/* Search Button */}
                <button
                  type="submit"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-black"
                >
                  <HiMagnifyingGlass className="h-5 w-5" />
                </button>
              </form>

              {/* Close */}
              <button
                onClick={toggleSearch}
                className="p-2 hover:bg-gray-100 rounded transition"
              >
                <HiMiniXMark className="h-6 w-6 text-gray-700" />
              </button>
            </div>
          </div>

          {/* Click outside area */}
          <div className="absolute inset-0 -z-10" onClick={toggleSearch}></div>
        </div>
      )}
    </>
  );
};

export default SearchBar;
